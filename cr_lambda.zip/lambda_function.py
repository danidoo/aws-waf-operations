import requests
import json
from crhelper import CfnResource

helper = CfnResource()

@helper.create
def create_component(event, _):
    param = ['es_domain']
    for p in param:
        if p not in event['ResourceProperties']:
            raise ValueError('Parameter missing: %s' % p)
            exit
        else:
            es_url = event['ResourceProperties']['es_domain']
    print(event['ResourceProperties']['es_domain'])
    try:
        url = "https://{}/_plugin/kibana/api/saved_objects/_import?overwrite=true".format(es_url)
        headers = { "kbn-xsrf": "true" }
        files = { 'file': open('awswaf-es-index.ndjson', 'rb') }
        response = requests.post(url, files=files, headers=headers)
        print(response.content)
    except Exception as err:
        raise ValueError("Couldn't create ElasticSearch index")
    
    try:
        url = "https://{}/_template/date_template?pretty".format(es_url)
        headers = { "kbn-xsrf": "true", "Content-Type": "application/json" }
        with open('awswaf-es-index-template.json') as json:
            response = requests.put(url, data=json, headers=headers)
            print(response.content)
    except Exception as err:
        raise ValueError("Couldn't create ElasticSearch index")

    try:
        url = "https://{}/_plugin/kibana/api/saved_objects/_import?overwrite=true".format(es_url)
        headers = { "kbn-xsrf": "true" }
        files = { 'file': open('awswaf-es-visualizations.ndjson', 'rb') }
        response = requests.post(url, files=files, headers=headers)
        print(response.content)
    except Exception as err:
        raise ValueError("Couldn't create ElasticSearch visualizations")

    try:
        url = "https://{}/_plugin/kibana/api/saved_objects/_import?overwrite=true".format(es_url)
        headers = { "kbn-xsrf": "true" }
        files = { 'file': open('awswaf-es-dashboards.ndjson', 'rb') }
        response = requests.post(url, files=files, headers=headers)
        print(response.content)
    except Exception as err:
        raise ValueError("Couldn't create ElasticSearch dashboards")

    return response

@helper.update
def no_op(_, __):
    pass

@helper.delete
def no_op2(_, __):
    pass

def lambda_handler(event, context):
    helper(event, context)
